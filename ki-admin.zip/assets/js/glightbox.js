 new GLightbox({
        touchNavigation: true,
        loop: true,
        width: "90vw",
        height: "90vh",
 });
